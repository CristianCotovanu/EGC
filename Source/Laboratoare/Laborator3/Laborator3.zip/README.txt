Cristian Cotovanu 336CA
Laborator 3 EGC

2. Am scris matricile pentru transformari
3. 
Animatia1: In functie de valoarea unui bool patratul are o translatie pe Oy cu un tY
cand acest tY depaseste o limita prestabilita schimb valoarea flag-ului 
Animatia2: Translatie in origine, rotatie in functie de origine (cresc nr de radiani), translatie inapoi
Animatia3: La fel ca la 1, in functie de un flag si niste limite modific scaleX si scaleY.
Apoi translatie in 0,0 pt centrul patratului, scalare si translatie inapoi

Bonus:
Animatia4: translatie pe patratul1, logica de la 2 pt rotatie si translatie la o distanta fata de patrata 

4. Pentru 
w/sus si s/jos modific fereastra logica pe Oy cu deltaTime
a/stanga si d/dreapta modific feresatra logica pe Ox cu deltaTime
z/x modific width si height in functie de deltaTime dar modific si coordonatele punctului 
x,y (colt stanga jos) cu jumatate din cat am adaugat/scazut din width si height pentru a recentra patratele.
