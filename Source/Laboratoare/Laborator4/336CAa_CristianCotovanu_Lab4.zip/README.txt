Cristian Cotovanu 336CA
Laborator 3 EGC

Task2
Am completat matricile asociate transformarilor

Task3
Am modificat in functie de deltaTime variabilele asociate celor 3 transformari

Bonus1: Jumping Box
Translatie pe Ox cu jumatate de raza in spate, 
Rotatie pe OZ (reset cand ajung la 180 de grade + cresc pozitia pe Ox), 
Translatie pe Ox cu jumatate de raza in fata

Bonus2: Solar System
sun: scalare, rotatie Oy, translatie la coordonate
earth: scalare, rotatie Oy in jurul centrului, 
translatie pe Ox cu distanta fata de soare, rotatie Oy in jurul soarelui, translatie la pozitia soarelui
moon: aceleasi transformari ca si earth doar ca se mai aplica o translatie cu distanta fata de pamant