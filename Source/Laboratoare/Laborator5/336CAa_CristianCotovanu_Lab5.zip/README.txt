Cristian Cotovanu 336CA
Laborator 5 EGC

Task2,3,4,5,7
Implementate conform TODOs

Task6
Am desenat cele 2 obiecte si construit matricile de modelare respective

Task 8
De pe tastele K si L se modifica valorile fov
